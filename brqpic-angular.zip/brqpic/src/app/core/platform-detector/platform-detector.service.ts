import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import{isPlatformBrowser} from '@angular/common';
@Injectable({providedIn: 'root'})
export class PlatformDetectorService{
    // injeto um identificador Plataform_ID em uma variável do tipo string
    constructor(@Inject(PLATFORM_ID) private platformId: string){}
    // o método retorna se a platform está no browser ou não
    isPlatformBrowser(){
        return isPlatformBrowser(this.platformId);
    }
}