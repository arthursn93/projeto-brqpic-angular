export interface NewUser{
    userName: string,
    email: string,
    fullname: string,
    password: string
}
