import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { PhotoModule } from "../photo/photo.module";
import { PhotosCommentsComponent } from "./photos-comments/photos-comments.component";
import { RouterModule } from "@angular/router";
import { PhotosDetailsComponent } from "./photos-details.component";
import { ReactiveFormsModule } from "@angular/forms";
import { VMessageModule } from "../../shared/components/vmessage/vmessage.module";
import { PhotoOwnerOnlyDirective } from "./photos-owner-only/photos-owner-only.directive";
import { ShowIfLoggedModule } from "../../shared/directives/show-if-logged/show-if-logged.module";

@NgModule({
    declarations: [
        PhotosDetailsComponent, 
        PhotosCommentsComponent,
        PhotoOwnerOnlyDirective
    ],
    exports: [
        PhotosDetailsComponent, 
        PhotosCommentsComponent
    ],
    imports: [
        RouterModule,
        CommonModule,
        PhotoModule,
        ReactiveFormsModule,
        VMessageModule,
        ShowIfLoggedModule    
    ]

})
export class PhotoDetailsModule{ }