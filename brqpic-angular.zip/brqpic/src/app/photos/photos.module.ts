import { NgModule } from '@angular/core';

import { PhotoListModule } from './photos-list/photo-list.module';
import { PhotoModule } from './photo/photo.module';
import { DarkOnHoverModule } from '../shared/directives/darken-on-hover/darken-on-hover.module';
import { PhotoDetailsModule } from './photos-details/photos-details.module';
import { PhotosFormModule } from './photos-form/photos-form.module';

@NgModule({
    imports: [
        PhotoModule,
        PhotosFormModule,
        PhotoListModule,
        DarkOnHoverModule,
        PhotoDetailsModule
        ]
})

export class PhotosModule{}

